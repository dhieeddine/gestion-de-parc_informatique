import {Component, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {MatTableDataSource} from '@angular/material/table';

@Component({
  selector: 'app-utilisateur',
  standalone: false,
  templateUrl: './utilisateur.html',
  styleUrl: './utilisateur.css'
})
export class Utilisateur implements OnInit {
  public utilisateur : any;
  public dataSource: any;
  public displayedColumns: string[] = ['numU', 'nomU','prenomU','droitU']

  constructor(private http: HttpClient) {
  }
  ngOnInit() {
    this.http.get('http://localhost:8000/utilisateurs').subscribe({
      next: value => {
        this.utilisateur = value;
        this.dataSource= new MatTableDataSource(this.utilisateur);
      },
      error: err => {console.log(err);}
    })
  }

}
