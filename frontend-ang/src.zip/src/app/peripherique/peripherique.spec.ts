import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Peripherique } from './peripherique';

describe('Peripherique', () => {
  let component: Peripherique;
  let fixture: ComponentFixture<Peripherique>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Peripherique]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Peripherique);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
