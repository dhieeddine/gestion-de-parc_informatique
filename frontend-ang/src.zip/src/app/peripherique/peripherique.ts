import {Component, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {AuthGuard} from '../gards/auth-guard';
import {MatTableDataSource} from '@angular/material/table';

@Component({
  selector: 'app-peripherique',
  standalone: false,
  templateUrl: './peripherique.html',
  styleUrl: './peripherique.css'
})
export class Peripherique implements OnInit {
  public peripherique : any;
  public dataSource: any;
  public displayedColumns: string[] = ['fournisseur', 'nomMateriel','typeP','garantie','etatMateriel','adrITMateriel']

  constructor(private http: HttpClient, private authGuard: AuthGuard) {
  }
  ngOnInit() {
    this.http.get('http://localhost:8000/peripherique').subscribe({
      next: value => {
        this.peripherique = value;
        this.dataSource= new MatTableDataSource(this.peripherique);
      },
      error: err => {console.log(err);}
    })
  }

}
