import {Component, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {AuthGuard} from '../gards/auth-guard';
import {MatTableDataSource} from '@angular/material/table';

@Component({
  selector: 'app-fournisseur',
  standalone: false,
  templateUrl: './fournisseur.html',
  styleUrl: './fournisseur.css'
})
export class Fournisseur implements OnInit {
  public fournisseur : any;
  public dataSource: any;
  public displayedColumns: string[] = ['numF','nomF','adresseF','codePF','telF']

  constructor(private http: HttpClient, private authGuard: AuthGuard) {
  }
  ngOnInit() {
    this.http.get('http://localhost:8000/fournisseurs').subscribe({
      next: value => {
        this.fournisseur = value;
        this.dataSource= new MatTableDataSource(this.fournisseur);
      },
      error: err => {console.log(err);}
    })
  }

}
