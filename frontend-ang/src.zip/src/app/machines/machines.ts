import {Component, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {AuthGuard} from '../gards/auth-guard';
import {MatTableDataSource} from '@angular/material/table';

@Component({
  selector: 'app-machines',
  standalone: false,
  templateUrl: './machines.html',
  styleUrl: './machines.css'
})
export class Machines implements OnInit {
  public machines : any;
  public dataSource: any;
  public displayedColumns: string[] = ['numMachine', 'ecran','marque','fournisseur','garantie','carteVideo','disqueDur','emplacement','typeMachine','dateAchat','processeur','stockage','ram','adrIp']

  constructor(private http: HttpClient, private authGuard: AuthGuard) {
  }
  ngOnInit() {
    this.http.get('http://localhost:8000/machines').subscribe({
      next: value => {
        this.machines = value;
        this.dataSource= new MatTableDataSource(this.machines);
      },
      error: err => {console.log(err);}
    })
  }

}
