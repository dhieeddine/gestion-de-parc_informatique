import {Component, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {AuthGuard} from '../gards/auth-guard';
import {MatTableDataSource} from '@angular/material/table';

@Component({
  selector: 'app-logiciel',
  standalone: false,
  templateUrl: './logiciel.html',
  styleUrl: './logiciel.css'
})
export class Logiciel implements OnInit {
  public logiciel: any;
  public dataSource: any;
  public displayedColumns: string[] = ['numL', 'nomL', 'typeL', 'licenceL', 'versionL', 'editeurL', 'numSeriel', 'dateL']

  constructor(private http: HttpClient, private authGuard: AuthGuard) {
  }

  ngOnInit() {
    this.http.get('http://localhost:8000/logiciels').subscribe({
      next: value => {
        this.logiciel = value;
        this.dataSource = new MatTableDataSource(this.logiciel);
      },
      error: err => {
        console.log(err);
      }
    })

  }
}
