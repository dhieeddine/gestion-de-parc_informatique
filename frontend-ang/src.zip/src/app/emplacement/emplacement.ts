import {Component, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {MatTableDataSource} from '@angular/material/table';

@Component({
  selector: 'app-emplacement',
  standalone: false,
  templateUrl: './emplacement.html',
  styleUrl: './emplacement.css'
})
export class Emplacement implements OnInit {
  public emplacement : any;
  public dataSource: any;
  public displayedColumns: string[] = ['numEmplacement','nomEmplacement','service']
  constructor(private http: HttpClient) {
  }
  ngOnInit() {
    this.http.get('http://localhost:8000/emplacements').subscribe({
      next: value => {
        this.emplacement = value;
        this.dataSource= new MatTableDataSource(this.emplacement);
      },
      error: err => {console.log(err);}
    })
  }

}
